const mysql = require("mysql2/promise");
require("dotenv").config({ quiet: true });

const poolConfig = {
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "lostfound",
  waitForConnections: true,
  connectionLimit: 10,
  connectTimeout: 15000,
};

// Only for cloud databases that require SSL. Leave DB_SSL unset on XAMPP and cPanel.
if (String(process.env.DB_SSL).toLowerCase() === "true") {
  poolConfig.ssl = { minVersion: "TLSv1.2", rejectUnauthorized: true };
}

const pool = mysql.createPool(poolConfig);